package dao.custom;

import dao.CrudDAO;
import entity.OrderDetails;

public interface OrderDetailsDAO extends CrudDAO<OrderDetails,String> {
}
